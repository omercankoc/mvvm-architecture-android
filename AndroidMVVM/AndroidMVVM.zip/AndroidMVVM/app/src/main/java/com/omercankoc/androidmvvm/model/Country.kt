package com.omercankoc.androidmvvm.model

data class Country(
    var country : String,
    var capital : String,
    var region : String,
    var currenccy : String,
    var language : String,
    var flag : String
)
