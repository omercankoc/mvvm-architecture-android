package com.omercankoc.androidmvvm.view

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.constraintlayout.motion.widget.DesignTool
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.ViewModelProviders
import com.omercankoc.androidmvvm.databinding.FragmentDetailBinding
import com.omercankoc.androidmvvm.viewmodel.DetailViewModel

class DetailFragment : Fragment() {

    // Definition Binding
    private lateinit var binding : FragmentDetailBinding

    private lateinit var detailViewModel : DetailViewModel

    private var UUID : Int = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Initialize Binding
        binding = FragmentDetailBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // ViewModel ile Fragmani bagla.
        detailViewModel = ViewModelProviders.of(this).get(DetailViewModel::class.java)
        detailViewModel.getDetailsFromRoom()
    }

    private fun observeLiveData(){
        detailViewModel.countryLiveData.observe(viewLifecycleOwner, Observer { country ->
            country?.let {
                binding.textViewCountry.text = country.country
                binding.textViewCapital.text = country.capital
                binding.textViewRegion.text = country.region
                binding.textViewCurrency.text = country.currenccy
                binding.textViewLanguage.text = country.language
            }
        })
    }
}